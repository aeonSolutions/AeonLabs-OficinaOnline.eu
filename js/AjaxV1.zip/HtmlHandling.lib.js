/* last update: 16-05-2016 */


/////////////////////////////////////////////////////////////////////////||\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

function DlgBox(msg) {
	document.getElementById('dlg-screen-mask').style.visibility='visible';
	document.getElementById('Dialogs').style.visibility='visible';
	document.getElementById('Dialogs').innerHTML=msg;
	
	setTimeout(CloseDlgBox(), 20000);
};

/////////////////////////////////////////////////////////////////////////||\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

function CloseDlgBox() {
	document.getElementById('dlg-screen-mask').style.visibility='hidden';
	document.getElementById('Dialogs').innerHTML="&nbsp";
};

